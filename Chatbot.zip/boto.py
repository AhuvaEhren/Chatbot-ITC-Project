"""
This is the template server side for ChatBot
"""
from bottle import route, run, template, static_file, request
import json
import random
import datetime
import re
import requests

names = ['ahuva', 'yoni','yaakov','jonathan','john','aviram']
greetings = ['Hola ','Shalom ','Hi ','Hello ','Hey ']
goodbye = ['goodbye', 'bye', 'ciao','see you later', 'peace out']
food = ['food','restaurant', 'restaurants', 'recs', 'recommendation', 'recommendations']
question = ['How can I help you today? Weather, food recs or looking to hear a joke?']
food_animation = ['excited', 'money', 'ok', 'dancing']
confused_animation =['confused', 'crying']
goodbye_animation = ['takeoff', 'heartbroke']
jokes = ["Why do programmers always get Christmas and Halloween mixed up? \n Because DEC 25 = OCT 31", "How do you keep a programmer in the shower all day? \n Give him a bottle of shampoo which says 'lather, rinse, repeat'"]
animal = ['animal', 'dog']

with open('swearwords.txt', "r") as swear_words:
    swear_words = swear_words.read()
    swear_words = re.sub('[^\w]', ' ', swear_words).split()

def analyzeAns(input):
    if any(item in input.lower() for item in names):
        return {"animation":'inlove',"msg": hello(input.lower())} 
    elif 'weather' in input.lower():
        return {"animation":'laughing',"msg":"I don't know, it's not raining by me!"}
    elif 'boo' in input.lower():
        return {"animation":'afraid',"msg":"ahhhhhhhhhh!"}
    elif any(item in input.lower() for item in food):
        return {"animation":random.choice(food_animation),"msg":"How about some pizza?"}
    elif any(item in input.lower() for item in swear_words):
        return {"animation":'no',"msg":"Please don't use that language here"}
    elif any(item in input.lower() for item in goodbye):
        return {"animation":random.choice(goodbye_animation),"msg": sign_off(input)}
    elif any(item in input.lower() for item in animal):
        return {"animation":'dog',"msg":"I love dogs, look how cute?!"}
    elif 'joke' in input.lower():
        return {"animation":'laughing', "msg": get_joke()}    
    else:
        return {"animation":random.choice(confused_animation),"msg":"I'm sorry, I don't understand your question"}


def hello(msg):
        if msg in names and not (' ' in msg):
            return f"{random.choice(greetings)} {msg}. How can I help you?"
        else:
            return f"{random.choice(greetings)} my friend. How can I help you?"

def sign_off(msg):
    if msg in goodbye:
        return random.choice(goodbye)

def get_joke():
    response = requests.get('http://api.icndb.com/jokes/random/')
    print('status_code: ', response.status_code)
    print(response.json())
    response_test = response.json()
    print(json.dumps(response_test))
    return json.dumps(response_test['value']['joke'])


@route('/', method='GET')
def index():
    return template("chatbot.html")


@route("/chat", method='POST')
def chat():
    user_message = request.POST.get('msg')
    return json.dumps(analyzeAns(user_message))


@route("/test", method='POST')
def chat():
    user_message = request.POST.get('msg')
    return json.dumps({"animation": "dancing", "msg": user_message})


@route('/js/<filename:re:.*\.js>', method='GET')
def javascripts(filename):
    return static_file(filename, root='js')


@route('/css/<filename:re:.*\.css>', method='GET')
def stylesheets(filename):
    return static_file(filename, root='css')


@route('/images/<filename:re:.*\.(jpg|png|gif|ico)>', method='GET')
def images(filename):
    return static_file(filename, root='images')


def main():
    run(host='localhost', port=7000)

if __name__ == '__main__':
    main()
